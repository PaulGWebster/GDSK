// Copyright 2022 the V8 project authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Flags:  test/mjsunit/modules-skip-1.mjs test/mjsunit/modules-skip-1.mjs

// Just test that d8 doesn't crash when running the same module on the
// command line twice.
