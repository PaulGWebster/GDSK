// Copyright 2024 the V8 project authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

class __c_1 extends Function {
  constructor(...__v_23) {
    super(... __v_23);
  }
}
// Create obj which triggers normalization
var __v_19 = new __c_1("'use strict';");
// Set prototype to a r/o object
__v_19.__proto__ = [];
