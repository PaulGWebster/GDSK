// Copyright 2018 the V8 project authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

const v1 = 0xFFFFFFFF;
const v3 = new Float64Array();
new Date(v3, v3, 0xFFFFFFFF,);
